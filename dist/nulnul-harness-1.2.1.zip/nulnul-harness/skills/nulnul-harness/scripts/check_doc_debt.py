#!/usr/bin/env python3
"""Report harness documents that are older than the sources they describe.

A fix that lands only in code is invisible to the next session. Comparing
modification times is enough: a false positive costs one warning line, a miss
costs re-deriving knowledge the project already had.
"""

import argparse
import json
import subprocess
from pathlib import Path

DOCUMENTS = ("AGENTS.md", "CLAUDE.md", "docs/nulnul/project.md", "README.md")
SKIP_DIRECTORIES = {".git", "node_modules", "__pycache__", "dist", "build", ".venv", "venv"}
SOURCE_SUFFIXES = {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".rb", ".java", ".sh", ".sql"}


def tracked_sources(root):
    result = subprocess.run(
        ["git", "-C", str(root), "ls-files"], capture_output=True, text=True
    )
    names = result.stdout.splitlines() if result.returncode == 0 else []
    if not names:
        names = [str(path.relative_to(root)) for path in root.rglob("*") if path.is_file()]
    for name in names:
        path = root / name
        if path.suffix in SOURCE_SUFFIXES and not SKIP_DIRECTORIES & set(path.parts) and path.is_file():
            yield path


def check(root, documents=DOCUMENTS):
    root = Path(root).resolve()
    sources = sorted(tracked_sources(root), key=lambda path: path.stat().st_mtime, reverse=True)
    newest = sources[0] if sources else None
    stale = []
    for name in documents:
        document = root / name
        if not document.is_file() or newest is None:
            continue
        if document.stat().st_mtime < newest.stat().st_mtime:
            ahead = [
                str(path.relative_to(root))
                for path in sources
                if path.stat().st_mtime > document.stat().st_mtime
            ]
            stale.append({"document": name, "newer_sources": len(ahead), "newest_source": ahead[0]})
    return stale


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path, nargs="?", default=Path("."))
    parser.add_argument("--document", action="append", dest="documents")
    args = parser.parse_args()
    stale = check(args.root, tuple(args.documents) if args.documents else DOCUMENTS)
    print(json.dumps({"documentation_debt": stale}, ensure_ascii=False, indent=2))
    for entry in stale:
        print(f"stale: {entry['document']} is older than {entry['newer_sources']} source files")
    raise SystemExit(bool(stale))


if __name__ == "__main__":
    main()
